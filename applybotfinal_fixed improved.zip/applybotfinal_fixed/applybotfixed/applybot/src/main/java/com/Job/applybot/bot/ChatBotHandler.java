package com.Job.applybot.bot;

import com.Job.applybot.Service.AnswerEngine;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * ChatBotHandler — v4 (send-button overhaul)
 *
 * KEY CHANGES vs v3:
 *
 * 1. WebSearchContext removed (caused ClassCastException with Spring DevTools classloader).
 *    All scoped searches now call WebElement.findElements() directly.
 *
 * 2. Send button: replaced all CSS-selector guessing with a JS DOM walk that
 *    locates the send button at runtime by inspecting every element inside the
 *    chatbot drawer. The JS looks for:
 *      a) any element whose class contains "send" (case-insensitive)
 *      b) any button/div that is a sibling/parent of the active text input
 *      c) any element with aria-label containing "send"
 *    This works regardless of what class name Naukri happens to use.
 *
 * 3. After chip/radio/checkbox click: added an explicit 1.5 s wait for the
 *    bot's next message before re-looping, so the loop doesn't close early.
 *
 * 4. isAcknowledgment: now only triggers on messages that are PURELY an ack
 *    (starts with one of the known phrases). Short messages that just start
 *    with "got it" but then continue with a question are NOT treated as acks.
 */
public class ChatBotHandler {

    // Chatbot container — used to scope DOM searches away from main Naukri page
    private static final String CHATBOT_SCOPE =
            ".chatbot_Drawer, .chatbot_Container, [class*='chatbot_Drawer']";

    // Chip selectors tried in order (scoped inside chatbot container)
    private static final String[] CHIP_SELECTORS = {
            "div.chatbot_Chip",
            "button.chatbot_Chip",
            "[class*='chatbot_Chip']",
            ".chatbot_OptionsContainer li",
            ".chatbot_OptionsContainer button",
            ".chatbot_OptionsContainer span",
            ".chatbot_InputContainer li",
            ".chatbot_InputContainer button",
            "li.chatbot_OptionItem",
            "[class*='chatbot_Option']",
            "[class*='chatbot_Button']"
    };

    private static final String[] KNOWN_SKILLS = {
            "java", "spring boot", "spring", "hibernate", "selenium",
            "react", "angular", "javascript", "python", "sql", "mysql",
            "mongodb", "rest api", "microservices", "docker", "git",
            "node", "typescript", "junit", "maven", "gradle", "aws",
            "kubernetes", "kafka", "redis", "jenkins"
    };

    private static final String[] ACK_PHRASES = {
            "thank you for your responses", "thank you for",
            "got it!", "got it.", "great!", "nice!", "awesome!", "amazing!",
            "perfect!", "wonderful!", "noted!", "sure!", "okay!", "alright!",
            "you can say something like"
    };

    // ─────────────────────────────────────────────────────────────────────────
    // MAIN ENTRY
    // ─────────────────────────────────────────────────────────────────────────
    public static void handle(WebDriver driver) {
        JavascriptExecutor js      = (JavascriptExecutor) driver;
        Actions            actions = new Actions(driver);
        String             lastQ        = "";
        int                stuckCount   = 0;
        int                lastMsgCount = 0;

        debug("=== ChatBotHandler START ===");

        try {
            switchToChatbotFrameIfPresent(driver);

            for (int turn = 0; turn < 30; turn++) {
                debug("--- Turn " + turn + " ---");
                waitForBotIdle(driver);

                String currentQ = getLatestQuestion(driver);
                debug("Question: [" + currentQ + "]");

                if (currentQ == null || currentQ.isBlank()) { debug("No question — ending."); break; }
                if (isChatDone(currentQ))                    { debug("Chat done.");             break; }

                if (isAcknowledgment(currentQ)) {
                    debug("Bot acknowledgment — waiting for closure or next question...");
                    try { Thread.sleep(2500); } catch (InterruptedException ignored) {}
                    if (isDrawerClosing(driver)) { debug("Drawer closing — ending."); break; }
                    continue;
                }

                if (currentQ.equalsIgnoreCase(lastQ)) {
                    if (++stuckCount >= 3) { debug("Stuck 3x — breaking."); break; }
                } else {
                    stuckCount = 0;
                }
                lastQ = currentQ;

                lastMsgCount = getBotMessageCount(driver);
                debug("Bot message count before answer: " + lastMsgCount);

                String answer = AnswerEngine.getAnswer(currentQ.toLowerCase());
                debug("Answer: [" + answer + "]");

                boolean handled = false;
                if (!handled) handled = tryChipClick(driver, js, currentQ, answer);
                if (!handled) handled = tryCheckboxes(driver, js, currentQ, answer);
                if (!handled) handled = tryRadioClick(driver, js, answer);
                if (!handled) handled = trySuggestionChip(driver, js, answer, actions);
                if (!handled) handled = tryTextInput(driver, js, actions, answer);

                if (!handled) {
                    debug("WARNING: Nothing handled this turn.");
                    dumpPageState(driver);
                }

                // Wait for the bot to reply before next turn
                waitForNewBotMessage(driver, lastMsgCount);
            }

            waitForDrawerClose(driver);

        } catch (Exception e) {
            debug("ERROR: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        } finally {
            driver.switchTo().defaultContent();
            debug("=== ChatBotHandler END ===");
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TYPE 1 — CHIPS / OPTION BUTTONS
    // ─────────────────────────────────────────────────────────────────────────
    private static boolean tryChipClick(WebDriver driver, JavascriptExecutor js,
                                        String question, String answer) {
        List<WebElement> chips = findChips(driver);
        if (chips.isEmpty()) return false;

        String[] chipTexts = new String[chips.size()];
        for (int i = 0; i < chips.size(); i++) {
            try { chipTexts[i] = chips.get(i).getText().trim().toLowerCase(); }
            catch (StaleElementReferenceException e) { chipTexts[i] = ""; }
        }

        debug("Found " + chips.size() + " chip(s):");
        for (int i = 0; i < chipTexts.length; i++) debug("  chip[" + i + "]: [" + chipTexts[i] + "]");

        boolean allSkip = true;
        for (String t : chipTexts) { if (!t.contains("skip")) { allSkip = false; break; } }
        if (allSkip && !answer.equalsIgnoreCase("skip")) {
            debug("Only skip chips — falling through.");
            return false;
        }

        // Resume/upload → click "later" or last chip
        if (question.toLowerCase().contains("resume") || question.toLowerCase().contains("upload")) {
            for (int i = 0; i < chipTexts.length; i++) {
                if (chipTexts[i].contains("later") || chipTexts[i].contains("skip"))
                    return clickChipAt(driver, js, chips, i);
            }
            return clickChipAt(driver, js, chips, chips.size() - 1);
        }

        String[] candidates = buildCandidates(answer);
        debug("Chip candidates: " + java.util.Arrays.toString(candidates));

        // ── Education-level question: match chip that best fits the degree ──
        if (question.toLowerCase().contains("highest") && (question.toLowerCase().contains("education")
                || question.toLowerCase().contains("qualification") || question.toLowerCase().contains("degree"))) {
            int eduIdx = pickEducationChip(chipTexts, answer);
            if (eduIdx >= 0) return clickChipAt(driver, js, chips, eduIdx);
        }

        // Pass 1: exact / contains match
        for (int i = 0; i < chipTexts.length; i++) {
            if (chipTexts[i].contains("skip")) continue;
            for (String c : candidates) {
                if (chipTexts[i].equals(c.toLowerCase()) || chipTexts[i].contains(c.toLowerCase()))
                    return clickChipAt(driver, js, chips, i);
            }
        }
        // Pass 2: prefix match
        for (int i = 0; i < chipTexts.length; i++) {
            if (chipTexts[i].contains("skip")) continue;
            for (String c : candidates) {
                if (chipTexts[i].startsWith(c.toLowerCase()))
                    return clickChipAt(driver, js, chips, i);
            }
        }
        // Skip chip if answer is "skip"
        if (answer.equalsIgnoreCase("skip")) {
            for (int i = 0; i < chipTexts.length; i++) {
                if (chipTexts[i].contains("skip")) return clickChipAt(driver, js, chips, i);
            }
        }

        // Default: if answer signals negative → last non-skip; else → first non-skip
        // "No", "no", "None", "nil", "0", "N/A", "n/a" all count as negative
        int firstNS = -1, lastNS = -1;
        for (int i = 0; i < chipTexts.length; i++) {
            if (!chipTexts[i].contains("skip")) {
                if (firstNS < 0) firstNS = i;
                lastNS = i;
            }
        }
        if (firstNS < 0) {
            if (answer.equalsIgnoreCase("skip")) return clickChipAt(driver, js, chips, 0);
            return false;
        }
        boolean negativeAnswer = answer.equalsIgnoreCase("No") || answer.equalsIgnoreCase("None")
                || answer.equalsIgnoreCase("nil") || answer.equals("0")
                || answer.equalsIgnoreCase("N/A") || answer.equalsIgnoreCase("n/a");
        int idx = negativeAnswer ? lastNS : firstNS;
        debug("Chip default idx=" + idx + ": [" + chipTexts[idx] + "] (answer=[" + answer + "])");
        return clickChipAt(driver, js, chips, idx);
    }

    private static List<WebElement> findChips(WebDriver driver) {
        // Scoped inside chatbot drawer first
        List<WebElement> scopes = driver.findElements(By.cssSelector(CHATBOT_SCOPE));
        if (!scopes.isEmpty()) {
            WebElement scope = scopes.get(0);
            for (String sel : CHIP_SELECTORS) {
                try {
                    List<WebElement> found = scope.findElements(By.cssSelector(sel));
                    List<WebElement> visible = visibleNonEmpty(found);
                    if (!visible.isEmpty()) {
                        debug("Chips (scoped) via [" + sel + "]: " + visible.size());
                        return visible;
                    }
                } catch (Exception ignored) {}
            }
        }
        // Unscoped fallback
        for (String sel : CHIP_SELECTORS) {
            try {
                List<WebElement> visible = visibleNonEmpty(driver.findElements(By.cssSelector(sel)));
                if (!visible.isEmpty()) {
                    debug("Chips (unscoped) via [" + sel + "]: " + visible.size());
                    return visible;
                }
            } catch (Exception ignored) {}
        }
        return java.util.Collections.emptyList();
    }

    private static boolean clickChipAt(WebDriver driver, JavascriptExecutor js,
                                       List<WebElement> chips, int idx) {
        try {
            if (idx >= chips.size()) return false;
            WebElement chip = chips.get(idx);
            String text = safeText(chip);
            js.executeScript("arguments[0].scrollIntoView({block:'center'});", chip);
            try { Thread.sleep(150); } catch (InterruptedException ignored) {}
            js.executeScript("arguments[0].click();", chip);
            debug("Clicked chip[" + idx + "]: [" + text + "] ✓");
            return true;
        } catch (StaleElementReferenceException e) {
            try {
                Thread.sleep(400);
                List<WebElement> fresh = findChips(driver);
                if (idx < fresh.size()) { js.executeScript("arguments[0].click();", fresh.get(idx)); return true; }
            } catch (Exception ignored) {}
            return false;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TYPE 2 — CHECKBOXES
    // ─────────────────────────────────────────────────────────────────────────
    private static boolean tryCheckboxes(WebDriver driver, JavascriptExecutor js,
                                         String question, String answer) {
        List<WebElement> checkboxes = findScoped(driver, "input[type='checkbox']");
        if (checkboxes.isEmpty()) return false;

        debug("Found " + checkboxes.size() + " checkbox(es):");
        String[] labels = new String[checkboxes.size()];
        for (int i = 0; i < checkboxes.size(); i++) {
            labels[i] = getCheckboxLabel(driver, checkboxes.get(i)).toLowerCase().trim();
            debug("  checkbox[" + i + "] label: [" + labels[i] + "]");
        }

        boolean anyChecked = false;
        String qLower = question.toLowerCase();

        if (qLower.contains("location") || qLower.contains("city") || qLower.contains("cities")) {
            for (int i = 0; i < labels.length; i++) {
                for (String c : buildCandidates(answer)) {
                    if (labels[i].contains(c.toLowerCase())) {
                        anyChecked |= clickCbAt(js, checkboxes, i); break;
                    }
                }
            }
            if (!anyChecked) anyChecked = clickCbAt(js, checkboxes, 0);
        } else {
            for (int i = 0; i < labels.length; i++) {
                for (String skill : KNOWN_SKILLS) {
                    if (labels[i].contains(skill)) {
                        anyChecked |= clickCbAt(js, checkboxes, i);
                        try { Thread.sleep(200); } catch (InterruptedException ignored) {}
                        break;
                    }
                }
            }
            if (!anyChecked) anyChecked = clickCbAt(js, checkboxes, 0);
        }

        try { Thread.sleep(400); } catch (InterruptedException ignored) {}
        clickSendButton(driver, js);
        return true;
    }

    private static boolean clickCbAt(JavascriptExecutor js, List<WebElement> cbs, int idx) {
        try {
            if (idx < cbs.size()) { js.executeScript("arguments[0].click();", cbs.get(idx)); return true; }
        } catch (Exception e) { debug("Checkbox click error idx=" + idx + ": " + e.getMessage()); }
        return false;
    }

    private static String getCheckboxLabel(WebDriver driver, WebElement cb) {
        try {
            String id = cb.getAttribute("id");
            if (id != null && !id.isBlank()) {
                List<WebElement> lbl = driver.findElements(By.cssSelector("label[for='" + id + "']"));
                if (!lbl.isEmpty()) return lbl.get(0).getText();
            }
        } catch (Exception ignored) {}
        try {
            Object t = ((JavascriptExecutor) driver).executeScript(
                    "var el=arguments[0],n=el.nextElementSibling;" +
                            "if(n&&n.tagName==='LABEL')return n.textContent;" +
                            "var p=el.parentElement;" +
                            "if(p){var l=p.querySelector('label');if(l)return l.textContent;return p.textContent;}" +
                            "return '';", cb);
            if (t != null) return t.toString().trim();
        } catch (Exception ignored) {}
        return "";
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TYPE 3 — RADIO BUTTONS
    //
    // FIX: Previous code only matched against radio id/value attributes.
    //      The radio labels (the visible text) are the correct thing to match.
    //      Now reads the label text for each radio and matches against answer.
    // ─────────────────────────────────────────────────────────────────────────
    private static boolean tryRadioClick(WebDriver driver, JavascriptExecutor js, String answer) {
        List<WebElement> radios = driver.findElements(By.cssSelector("input.ssrc__radio"));
        if (radios.isEmpty()) return false;

        debug("Found " + radios.size() + " radio(s):");
        String[] ids    = new String[radios.size()];
        String[] vals   = new String[radios.size()];
        String[] labels = new String[radios.size()];

        for (int i = 0; i < radios.size(); i++) {
            try {
                ids[i]  = safeAttr(radios.get(i), "id").toLowerCase().trim();
                vals[i] = safeAttr(radios.get(i), "value").toLowerCase().trim();
                // Read the associated label text — this is the visible option text
                String id = safeAttr(radios.get(i), "id");
                List<WebElement> lblEls = driver.findElements(By.cssSelector("label[for='" + id + "']"));
                labels[i] = lblEls.isEmpty() ? "" : lblEls.get(0).getText().trim().toLowerCase();
                debug("  radio[" + i + "]: id=[" + ids[i] + "] val=[" + vals[i] + "] label=[" + labels[i] + "]");
            } catch (StaleElementReferenceException e) {
                ids[i] = vals[i] = labels[i] = "";
            }
        }

        String ansLower = answer.toLowerCase().trim();
        String[] candidates = buildCandidates(answer);

        // Pass 1: exact match against label, value, or id
        for (int i = 0; i < radios.size(); i++) {
            if (ids[i].contains("skip")) continue;
            for (String c : candidates) {
                String cl = c.toLowerCase().trim();
                if (labels[i].equals(cl) || vals[i].equals(cl) || ids[i].equals(cl)) {
                    debug("Radio exact match [" + labels[i] + "] at idx=" + i);
                    return clickRadioAt(driver, js, i);
                }
            }
        }

        // Pass 2: contains match
        for (int i = 0; i < radios.size(); i++) {
            if (ids[i].contains("skip")) continue;
            for (String c : candidates) {
                String cl = c.toLowerCase().trim();
                if (labels[i].contains(cl) || cl.contains(labels[i]) ||
                        vals[i].contains(cl)   || ids[i].contains(cl)) {
                    debug("Radio contains match [" + labels[i] + "] at idx=" + i);
                    return clickRadioAt(driver, js, i);
                }
            }
        }

        // Pass 3: for Yes/No — "yes" → first non-skip, "no"/"none"/"nil" → last non-skip
        int firstNS = -1, lastNS = -1;
        for (int i = 0; i < ids.length; i++) {
            if (!ids[i].contains("skip") && !labels[i].contains("skip")) {
                if (firstNS < 0) firstNS = i;
                lastNS = i;
            }
        }
        if (firstNS >= 0) {
            boolean negativeAnswer = ansLower.equals("no") || ansLower.equals("none")
                    || ansLower.equals("nil") || ansLower.equals("0") || ansLower.equals("n/a");
            int idx = negativeAnswer ? lastNS : firstNS;
            debug("Radio default [" + ansLower + "] → idx=" + idx + " label=[" + labels[idx] + "]");
            return clickRadioAt(driver, js, idx);
        }

        return clickRadioAt(driver, js, 0);
    }

    private static boolean clickRadioAt(WebDriver driver, JavascriptExecutor js, int idx) {
        try {
            List<WebElement> fresh = driver.findElements(By.cssSelector("input.ssrc__radio"));
            if (idx >= fresh.size()) return false;
            WebElement radio = fresh.get(idx);
            String id = safeAttr(radio, "id");
            List<WebElement> lbls = driver.findElements(By.cssSelector("label[for='" + id + "']"));
            if (!lbls.isEmpty()) js.executeScript("arguments[0].click();", lbls.get(0));
            else                  js.executeScript("arguments[0].click();", radio);
            debug("Clicked radio[" + idx + "] ✓");
            try { Thread.sleep(500); } catch (InterruptedException ignored) {}
            clickSendButton(driver, js);
            return true;
        } catch (Exception e) { debug("Radio click error: " + e.getMessage()); return false; }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TYPE 4 — SUGGESTION CHIP / d-none input
    // ─────────────────────────────────────────────────────────────────────────
    private static boolean trySuggestionChip(WebDriver driver, JavascriptExecutor js,
                                             String answer, Actions actions) {
        List<WebElement> containers = driver.findElements(By.cssSelector("div.chatbot_SendMessageContainer"));
        if (containers.isEmpty() || !safeAttr(containers.get(0), "class").contains("d-none")) return false;

        List<WebElement> suggestions = driver.findElements(By.cssSelector(
                ".chatbot_SuggestionChip,.suggestion-chip,[class*='SuggestionChip']," +
                        ".chatbot_prefill,.prefillChip,.chatbot_EditChip,[class*='editChip']"));
        if (!suggestions.isEmpty()) {
            debug("Suggestion chip: [" + safeText(suggestions.get(0)) + "]");
            js.executeScript("arguments[0].click();", suggestions.get(0));
            return true;
        }

        debug("d-none input — force-removing d-none");
        js.executeScript(
                "document.querySelectorAll('.chatbot_SendMessageContainer')" +
                        ".forEach(function(el){ el.classList.remove('d-none'); });");
        try { Thread.sleep(500); } catch (InterruptedException ignored) {}
        return false;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TYPE 5 — TEXT INPUT
    //
    // IMPORTANT: AutocompleteHandler is NOT used here. It queries global
    // Naukri page dropdowns ([class*='Dropdown'] div) which match the site
    // navigation search bar — causing navigation away from the page.
    // The chatbot text input only needs: clear → type → dispatchEvent → sendMsg.
    // ─────────────────────────────────────────────────────────────────────────
    private static boolean tryTextInput(WebDriver driver, JavascriptExecutor js,
                                        Actions actions, String answer) {
        List<WebElement> containers = driver.findElements(By.cssSelector("div.chatbot_SendMessageContainer"));
        if (!containers.isEmpty() && safeAttr(containers.get(0), "class").contains("d-none")) {
            debug("Text container d-none — skipping."); return false;
        }

        WebElement input = findChatbotTextInput(driver);
        if (input == null) { debug("No chatbot text input found."); return false; }
        debug("Text input found: id=[" + safeAttr(input, "id") + "]");

        try {
            // Step 1: scroll into view and focus
            js.executeScript("arguments[0].scrollIntoView({block:'center'});", input);
            Thread.sleep(200);
            js.executeScript("arguments[0].focus();", input);
            Thread.sleep(200);

            // Step 2: clear ALL existing content (contenteditable div reuses same element)
            js.executeScript(
                    "var el=arguments[0];" +
                            "el.innerText='';" +
                            "el.textContent='';" +
                            "el.value='';" +
                            "el.dispatchEvent(new InputEvent('input',{bubbles:true}));",
                    input);
            Thread.sleep(150);
            // Also keyboard-clear in case JS clear didn't fully reset
            input.sendKeys(Keys.chord(Keys.CONTROL, "a"), Keys.BACK_SPACE);
            Thread.sleep(200);

            // Step 3: type the answer ONCE via sendKeys only
            // (do NOT also set innerText — that causes double entry)
            input.sendKeys(answer);
            Thread.sleep(300);

            // Step 4: dispatch events so chatbot enables the send button
            js.executeScript(
                    "var el=arguments[0];" +
                            "el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText'}));" +
                            "el.dispatchEvent(new Event('change',{bubbles:true}));" +
                            "el.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'a'}));",
                    input);
            Thread.sleep(400);

            debug("Text typed: [" + answer + "]");

            // Step 6: remove disabled from send button then click it
            clickSendButton(driver, js);
            return true;

        } catch (Exception e) {
            debug("tryTextInput error: " + e.getMessage());
            return false;
        }
    }

    private static WebElement findChatbotTextInput(WebDriver driver) {
        // 1: inside chatbot_SendMessageContainer (not d-none)
        for (WebElement c : driver.findElements(By.cssSelector("div.chatbot_SendMessageContainer"))) {
            try {
                if (safeAttr(c, "class").contains("d-none")) continue;
                for (WebElement inp : c.findElements(
                        By.cssSelector("div[contenteditable='true'],input[type='text'],textarea"))) {
                    try { if (inp.isDisplayed()) return inp; } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
        }
        // 2: inside .chatbot_Drawer
        for (WebElement d : driver.findElements(By.cssSelector(".chatbot_Drawer"))) {
            try {
                for (WebElement inp : d.findElements(
                        By.cssSelector("div[contenteditable='true'],input[type='text'],textarea"))) {
                    try { if (inp.isDisplayed()) return inp; } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
        }
        // 3: by ID pattern — chatbot inputs have ids like userInput__xxxInputBox
        for (WebElement inp : driver.findElements(By.cssSelector(
                "div[contenteditable='true'][id*='InputBox']," +
                        "div[contenteditable='true'][id*='userInput']," +
                        "div[contenteditable='true'][id*='chatbot']"))) {
            try { if (inp.isDisplayed()) return inp; } catch (Exception ignored) {}
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SEND BUTTON
    //
    // Strategy: use a JS DOM walk inside the chatbot drawer to find the send
    // button at runtime. This is more reliable than guessing class names.
    //
    // JS logic:
    //   1. Find all elements inside .chatbot_Drawer whose className contains "send"
    //   2. Find any button/div that is adjacent to (sibling/parent of) the text input
    //   3. Find any element with aria-label containing "send"
    //   4. Click the first visible match
    // ─────────────────────────────────────────────────────────────────────────
    private static void clickSendButton(WebDriver driver, JavascriptExecutor js) {
        debug("Clicking send button...");
        try {
            // The Naukri chatbot send button HTML is exactly:
            //   <div id="sendMsg__xxxInputBox" class="send">
            //     <div class="sendMsg" tabindex="0">Save</div>
            //   </div>
            // So: un-disable both, then click div.sendMsg directly.

            // Step 1: remove disabled from div.send and div.sendMsg
            js.executeScript(
                    "document.querySelectorAll('div.send, div.sendMsg').forEach(function(el){" +
                            "  el.classList.remove('disabled');" +
                            "  el.removeAttribute('disabled');" +
                            "});");
            try { Thread.sleep(300); } catch (InterruptedException ignored) {}

            // Step 2: click div.sendMsg — THE save button
            Boolean clicked = (Boolean) js.executeScript(
                    "var btns = document.querySelectorAll('div.sendMsg');" +
                            "for(var i=0;i<btns.length;i++){" +
                            "  if(btns[i].offsetParent !== null){" +  // visible
                            "    btns[i].click(); return true;" +
                            "  }" +
                            "}" +
                            "return false;");
            if (Boolean.TRUE.equals(clicked)) {
                debug("Clicked div.sendMsg via JS ✓");
                return;
            }

            // Step 3: Selenium findElements fallback for div.sendMsg
            List<WebElement> sendMsgs = driver.findElements(By.cssSelector("div.sendMsg"));
            debug("div.sendMsg elements found: " + sendMsgs.size());
            for (WebElement btn : sendMsgs) {
                try {
                    if (btn.isDisplayed()) {
                        js.executeScript("arguments[0].click();", btn);
                        debug("Clicked div.sendMsg via Selenium ✓  text=[" + safeText(btn) + "]");
                        return;
                    }
                } catch (StaleElementReferenceException ignored) {}
            }

            // Step 4: click parent div.send[id^='sendMsg__']
            List<WebElement> sendDivs = driver.findElements(By.cssSelector("div[id^='sendMsg__']"));
            debug("div[id^='sendMsg__'] elements found: " + sendDivs.size());
            for (WebElement btn : sendDivs) {
                try {
                    if (btn.isDisplayed()) {
                        js.executeScript("arguments[0].click();", btn);
                        debug("Clicked div[id^='sendMsg__'] ✓");
                        return;
                    }
                } catch (StaleElementReferenceException ignored) {}
            }

            // Step 5: Enter key on chatbot text input as last resort
            debug("All selectors missed — pressing Enter on input...");
            WebElement inp = findChatbotTextInput(driver);
            if (inp != null) {
                inp.sendKeys(Keys.RETURN);
                debug("Pressed Enter on text input ✓");
                return;
            }

            debug("Send button: all strategies exhausted.");
        } catch (Exception e) { debug("Send button error: " + e.getMessage()); }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /** Find elements scoped inside chatbot container, fallback to page-wide */
    private static List<WebElement> findScoped(WebDriver driver, String css) {
        List<WebElement> scopes = driver.findElements(By.cssSelector(CHATBOT_SCOPE));
        if (!scopes.isEmpty()) {
            List<WebElement> found = scopes.get(0).findElements(By.cssSelector(css));
            if (!found.isEmpty()) return found;
        }
        return driver.findElements(By.cssSelector(css));
    }

    private static List<WebElement> visibleNonEmpty(List<WebElement> els) {
        List<WebElement> result = new ArrayList<>();
        for (WebElement el : els) {
            try { if (el.isDisplayed() && !el.getText().trim().isEmpty()) result.add(el); }
            catch (Exception ignored) {}
        }
        return result;
    }

    private static boolean isAcknowledgment(String q) {
        // Only treat as ack if the message is SHORT (< 80 chars) and starts with an ack phrase
        // Longer messages that happen to start with "great!" usually continue with a question
        String lower = q.toLowerCase().trim();
        if (lower.length() > 120) return false;
        for (String phrase : ACK_PHRASES) {
            if (lower.startsWith(phrase) || lower.equals(phrase)) return true;
        }
        return false;
    }

    private static boolean isDrawerClosing(WebDriver driver) {
        List<WebElement> drawers = driver.findElements(By.cssSelector(".chatbot_Drawer"));
        if (drawers.isEmpty()) return true;
        try { return "none".equals(drawers.get(0).getCssValue("display")); }
        catch (Exception e) { return true; }
    }

    private static String getLatestQuestion(WebDriver driver) {
        List<WebElement> spans = driver.findElements(By.cssSelector("li.botItem .botMsg span"));
        debug("li.botItem .botMsg span count: " + spans.size());
        for (int i = spans.size() - 1; i >= 0; i--) {
            try { String t = spans.get(i).getText().trim(); if (!t.isBlank()) return t; }
            catch (StaleElementReferenceException ignored) {}
        }
        return null;
    }

    private static void waitForBotIdle(WebDriver driver) {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(8)).until(d ->
                    d.findElements(By.cssSelector(".botTyping,.typing-indicator,.bot-typing")).isEmpty());
        } catch (Exception ignored) {}
        try { Thread.sleep(800); } catch (InterruptedException ignored) {}
    }

    private static void waitForNewBotMessage(WebDriver driver, int prevCount) {
        debug("Waiting for new bot message (prev=" + prevCount + ")...");
        try {
            new WebDriverWait(driver, Duration.ofSeconds(12)).until(d ->
                    d.findElements(By.cssSelector("li.botItem .botMsg span")).size() > prevCount);
            debug("New bot message received ✓");
        } catch (TimeoutException e) { debug("No new message within 12s — continuing."); }
    }

    private static void waitForDrawerClose(WebDriver driver) {
        debug("Waiting for drawer to close...");
        try {
            new WebDriverWait(driver, Duration.ofSeconds(20)).until(d -> {
                List<WebElement> drawers = d.findElements(By.cssSelector(".chatbot_Drawer"));
                if (drawers.isEmpty()) return true;
                try { return "none".equals(drawers.get(0).getCssValue("display")); }
                catch (Exception e) { return true; }
            });
            debug("Drawer closed ✓");
        } catch (TimeoutException e) { debug("Drawer did not close in 20s — moving on."); }
    }

    private static int getBotMessageCount(WebDriver driver) {
        try { return driver.findElements(By.cssSelector("li.botItem .botMsg span")).size(); }
        catch (Exception e) { return 0; }
    }

    private static void switchToChatbotFrameIfPresent(WebDriver driver) {
        for (WebElement frame : driver.findElements(By.tagName("iframe"))) {
            try {
                String src = frame.getAttribute("src");
                if (src != null && src.toLowerCase().contains("chatbot")) {
                    driver.switchTo().frame(frame); debug("Switched into chatbot iframe."); return;
                }
            } catch (Exception ignored) {}
        }
        debug("No chatbot iframe — using main DOM.");
    }

    private static boolean isChatDone(String q) {
        String l = q.toLowerCase();
        return l.contains("applied successfully") || l.contains("your application has been");
    }

    private static void dumpPageState(WebDriver driver) {
        debug("--- PAGE STATE DUMP ---");
        List<WebElement> chips = findChips(driver);
        debug("Chips: " + chips.size());
        for (WebElement c : chips) { try { debug("  [" + c.getText().trim() + "] tag=" + c.getTagName()); } catch (Exception ignored) {} }
        debug("Checkboxes: " + findScoped(driver, "input[type='checkbox']").size());
        debug("Radios: " + driver.findElements(By.cssSelector("input.ssrc__radio")).size());
        List<WebElement> conts = driver.findElements(By.cssSelector("div.chatbot_SendMessageContainer"));
        debug("SendContainers: " + conts.size());
        for (WebElement c : conts) debug("  class=[" + safeAttr(c, "class") + "]");
        WebElement inp = findChatbotTextInput(driver);
        debug("TextInput: " + (inp != null ? "FOUND id=[" + safeAttr(inp,"id") + "]" : "NOT FOUND"));

        // Dump all elements with 'send' in class inside drawer
        debug("Elements with 'send' in class inside drawer:");
        try {
            List<WebElement> scopes = driver.findElements(By.cssSelector(".chatbot_Drawer"));
            if (!scopes.isEmpty()) {
                List<WebElement> all = scopes.get(0).findElements(By.cssSelector("*"));
                for (WebElement el : all) {
                    try {
                        String cn = safeAttr(el, "class");
                        if (cn.toLowerCase().contains("send")) {
                            debug("  tag=" + el.getTagName() + " class=[" + cn + "] visible=" + el.isDisplayed());
                        }
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}
        debug("--- END DUMP ---");
    }

    /**
     * Picks the chip index that best matches the user's education level.
     * Avoids accidentally clicking "Below 12th", "10th", etc. when user has a degree.
     *
     * Priority order (highest match wins):
     *   1. Exact or contains match for the degree string (e.g. "b.tech", "b.e", "bachelor")
     *   2. Alias match ("graduate" for B.Tech/B.E, "post graduate" for M.Tech/MBA, etc.)
     *   3. Never clicks "below 12", "below class 12", "10th", "12th" if user has a degree
     *
     * Returns -1 if no match found (caller falls through to normal chip logic).
     */
    private static int pickEducationChip(String[] chipTexts, String answer) {
        String ansLower = answer.toLowerCase().trim();

        // Map degree aliases to chip keyword patterns
        String[][] degreeAliases = {
                // { answer keyword,  chip keywords... }
                {"b.tech",  "b.tech", "b.e", "bachelor", "graduate", "engineering", "be/b.tech"},
                {"b.e",     "b.e", "b.tech", "bachelor", "engineering", "be/b.tech"},
                {"bachelor","bachelor", "b.tech", "b.e", "graduate", "ug", "under graduate"},
                {"bsc",     "bsc", "b.sc", "bachelor", "graduate"},
                {"bca",     "bca", "bachelor", "graduate"},
                {"mba",     "mba", "post graduate", "pg", "master"},
                {"m.tech",  "m.tech", "m.e", "master", "post graduate", "pg"},
                {"m.e",     "m.e", "m.tech", "master", "post graduate"},
                {"msc",     "msc", "m.sc", "master", "post graduate"},
                {"mca",     "mca", "master", "post graduate"},
                {"phd",     "phd", "doctorate", "doctor"},
                {"diploma", "diploma"},
                {"12th",    "12th", "hsc", "higher secondary", "intermediate"},
                {"10th",    "10th", "ssc", "secondary"},
        };

        // Chips that must NEVER be selected if the user has a degree
        String[] lowEducationChips = {"below 12", "below class 12", "10th", "ssc", "secondary school",
                "less than", "up to 10", "up to 12"};

        // First, find chips that are clearly too low for a graduate
        boolean userIsGraduate = ansLower.contains("b.tech") || ansLower.contains("b.e")
                || ansLower.contains("bachelor") || ansLower.contains("bca") || ansLower.contains("bsc")
                || ansLower.contains("m.tech") || ansLower.contains("mba") || ansLower.contains("mca")
                || ansLower.contains("msc") || ansLower.contains("master") || ansLower.contains("phd")
                || ansLower.contains("diploma");

        // Build a set of forbidden chip indices
        java.util.Set<Integer> forbidden = new java.util.HashSet<>();
        if (userIsGraduate) {
            for (int i = 0; i < chipTexts.length; i++) {
                for (String low : lowEducationChips) {
                    if (chipTexts[i].contains(low)) { forbidden.add(i); break; }
                }
            }
        }

        // Find the best matching chip
        for (String[] alias : degreeAliases) {
            boolean answerMatchesAlias = ansLower.contains(alias[0]);
            if (!answerMatchesAlias) continue;
            // Try each keyword for this degree
            for (int k = 1; k < alias.length; k++) {
                for (int i = 0; i < chipTexts.length; i++) {
                    if (forbidden.contains(i)) continue;
                    if (chipTexts[i].contains(alias[k])) {
                        debug("Education chip match: alias[" + alias[0] + "] → chip[" + i + "]: [" + chipTexts[i] + "]");
                        return i;
                    }
                }
            }
        }

        // No alias matched — return first non-forbidden, non-skip chip
        for (int i = 0; i < chipTexts.length; i++) {
            if (!forbidden.contains(i) && !chipTexts[i].contains("skip")) return i;
        }
        return -1;
    }

    private static String[] buildCandidates(String answer) {
        return switch (answer.toLowerCase().trim()) {
            case "yes"             -> new String[]{"Yes","yes"};
            case "no"              -> new String[]{"No","no"};
            case "none","nil","n/a"-> new String[]{"No","None","nil","N/A","Not applicable","not applicable"};
            case "male"            -> new String[]{"Male","male"};
            case "female"          -> new String[]{"Female","female"};
            case "30","30 days"    -> new String[]{"30 days","1 month","1 Month","30"};
            case "15","15 days"    -> new String[]{"15 days","15 Days or less","15"};
            case "45","45 days"    -> new String[]{"45 days","45"};
            case "60","60 days"    -> new String[]{"60 days","2 months","2 Months","60"};
            case "75","75 days"    -> new String[]{"75 days","3 months","3 Months","75"};
            case "0","immediately" -> new String[]{"Immediately","0 days","Immediate"};
            // Education aliases — so chip matching finds the right option
            case "b.tech","b.e","be/b.tech" ->
                    new String[]{"B.Tech","B.E","BE/B.Tech","Bachelor of Technology",
                            "Bachelor of Engineering","Graduate","Engineering"};
            case "bachelor","bsc","bca","ba","bcom" ->
                    new String[]{"Bachelor","Graduate","UG","Under Graduate","B.Sc","BCA","B.A","B.Com"};
            case "m.tech","m.e"    ->
                    new String[]{"M.Tech","M.E","Master of Technology","Post Graduate","PG"};
            case "mba"             ->
                    new String[]{"MBA","Master of Business","Post Graduate","PG"};
            case "msc","mca","ma","mcom" ->
                    new String[]{"Master","Post Graduate","PG","M.Sc","MCA","M.A","M.Com"};
            case "phd"             ->
                    new String[]{"PhD","Doctorate","Doctor of Philosophy"};
            case "diploma"         ->
                    new String[]{"Diploma","Polytechnic"};
            case "12th","hsc","higher secondary","intermediate" ->
                    new String[]{"12th","HSC","Higher Secondary","Intermediate","Plus Two","10+2"};
            case "10th","ssc","secondary" ->
                    new String[]{"10th","SSC","Secondary","Matriculation"};
            // Location aliases
            case "chennai"         -> new String[]{"Chennai","chennai","tamil nadu"};
            case "bengaluru"       -> new String[]{"Bengaluru","bangalore"};
            case "mumbai"          -> new String[]{"Mumbai","bombay"};
            case "hyderabad"       -> new String[]{"Hyderabad"};
            default                -> new String[]{answer};
        };
    }

    private static String safeAttr(WebElement el, String attr) {
        try { String v = el.getAttribute(attr); return v == null ? "" : v; }
        catch (Exception e) { return ""; }
    }

    private static String safeText(WebElement el) {
        try { return el.getText().trim(); } catch (Exception e) { return ""; }
    }

    private static void debug(String msg) { System.out.println("[ChatBot] " + msg); }
}
